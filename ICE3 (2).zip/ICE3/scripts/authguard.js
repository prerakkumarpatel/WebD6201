(function(){
if(!sessionStorage.getItem("user")){
location.href="login.html";
console.log("auhsdhfhd");
}
    }

)();