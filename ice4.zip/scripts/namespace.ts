"use strict";
namespace  core{

}